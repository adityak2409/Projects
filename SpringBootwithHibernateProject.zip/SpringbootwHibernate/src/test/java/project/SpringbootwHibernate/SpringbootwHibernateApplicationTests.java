package project.SpringbootwHibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootwHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
